export class Phone {
    constructor (public id:number, 
        public producer:string, 
        public name:string, 
        public model:string){}
}
