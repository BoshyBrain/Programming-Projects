﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class FictionBook: Book
    {
        public string Genre { get; set; }
        
        public FictionBook(string bookName, string authorName, string genre) : base(bookName, authorName)
        {
            this.Genre = genre;
        }

        public override void LoanBook()
        {
            base.LoanBook();
            Console.WriteLine($"Genre: {Genre}");
        }

        public override string ToString()
        {
            return base.ToString() + $"Genre: {Genre}";
        }
    }
}
