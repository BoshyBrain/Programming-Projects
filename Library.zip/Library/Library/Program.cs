﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Library
{
    internal class Library
    {
        private Book[] books = new Book[25];
        private Subscriber[] subscribers = new Subscriber[25];
        private int bookCount = 0;
        private int subsCount = 0;

        public Library()
        {
            books = new Book[25];
            subscribers = new Subscriber[25];
            bookCount = 0;
            subsCount = 0;
        }

        public void AddBook(Book book)
        {

            foreach (var b in books)
            {
                if (b != null && b.Equals(book))
                {
                    Console.WriteLine("Book is already exists.");
                    return;
                }
            }

            if(bookCount < books.Length)
            {
                books[bookCount++] = book;
                Console.WriteLine("Book added successfully.");
            }
            else
            {
                Console.WriteLine("Library is full.");
            }
            
        }

        public void AddSubscriber(Subscriber subscriber)
        {
            foreach (var s in subscribers)
            {
                if (s != null && s.Equals(subscriber))
                {
                    Console.WriteLine("Subscriber is already exist.");
                    return;
                }
            }
            if (subsCount < subscribers.Length)
            {
                subscribers[subsCount++] = subscriber;
                Console.WriteLine("Subscriber added successuflly.");
            }
            else
            {
                Console.WriteLine("Subscribers list is full");
            }
        }

        public void BorrowBook(int id, string title, string authorName)
        {
            Subscriber subscriber = null;
            Book book = null;

            foreach (var s in subscribers)
            {
                if(s != null && s.Id == id)
                {
                    subscriber = s;
                    break;
                }
            }

            if (subscriber == null)
            {
                Console.WriteLine("Subscriber does not exist.");
                return;
            }

            foreach (var b in books)
            {
                if(b != null && b.Title == title && b.AuthorName == authorName)
                {
                    book = b;
                    break;
                }
            }

            if(book == null)
            {
                Console.WriteLine("Book does not exist.");
                return;
            }

            if(book.IsLoaned || (book is ReferenceBook && !((ReferenceBook)book).IsAvailableForLoan))
            {
                Console.WriteLine("Book is unavailable for loan.");
                return;
            }

            if(subscriber.LoanedBooks >= 3)
            {
                Console.WriteLine("Subscriber has loaned maximum allowed books.");
                return;
            }

            subscriber.LoanedBooks++;
            book.IsLoaned = true;
            Console.WriteLine("Book was succsesfully loaned.");
        }

        public void ReturnBook(int id, string title, string authorName)
        {
            Subscriber subscriber = null;
            Book book = null;

            foreach (var s in subscribers)
            {
                if (s != null && s.Id == id)
                {
                    subscriber = s;
                    break;
                }
            }

            if (subscriber == null)
            {
                Console.WriteLine("Subscriber does not exist.");
                return;
            }

            foreach (var b in books)
            {
                if (b != null && b.Title == title && b.AuthorName == authorName)
                {
                    book = b;
                    break;
                }
            }

            if (book == null)
            {
                Console.WriteLine("Book does not exist.");
                return;
            }

            if (!book.IsLoaned)
            {
                Console.WriteLine("Book is available for loan.");
                return;
            }

            subscriber.LoanedBooks--;
            book.IsLoaned = false;
            Console.WriteLine("Book was successfully returned.");
        }

        public void AllBooksInfo()
        {
            foreach (var book in books)
            {
                if(book != null)
                {
                    Console.WriteLine(book.ToString());
                }
            }
        }

        public void DisplayBooksByGenre(string genre)
        {
            foreach (var book in books)
            {
                if (book is FictionBook fictionBook && fictionBook.Genre == genre)
                {
                    Console.WriteLine(fictionBook.ToString());
                }
            }
        }




        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Library library = new Library();
            bool isRunning = true;

            while(isRunning)
            {
                Console.Clear();

                Console.WriteLine("Select an action:");
                Console.WriteLine("1. Add book");
                Console.WriteLine("2. Add subscriber");
                Console.WriteLine("3. Borrow book");
                Console.WriteLine("4. Return book");
                Console.WriteLine("5. Display all books");
                Console.WriteLine("6. Display books by genre");
                Console.WriteLine("7. Exit");
                Console.WriteLine("-- " + new string('#', 25) + " --");
                string input = Console.ReadLine();
                int action;

                if(!int.TryParse(input, out action) || action < 1  || action > 7)
                {
                    Console.WriteLine("Invalid character. Try another number.");
                    continue;
                }

                switch (action)
                {
                    case 1:
                        Console.WriteLine("Enter book type (Fiction, Reference):");
                        string bookType = Console.ReadLine().ToLower();
                        Console.WriteLine("Enter book title: ");
                        string bookName = Console.ReadLine();
                        Console.WriteLine("Enter author name: ");
                        string authorName = Console.ReadLine();

                        if (bookType == "fiction")
                        {
                            Console.WriteLine("Enter genre:");
                            string genreSearch = Console.ReadLine();
                            library.AddBook(new FictionBook(bookName, authorName, genreSearch));
                        }
                        else if(bookType == "reference")
                        {
                            Console.WriteLine("Can the book be loaned? Yes/No");
                            string isAvailable = Console.ReadLine().ToLower();
                            bool borrowable = isAvailable == "yes";
                            library.AddBook(new ReferenceBook(bookName, authorName, borrowable));
                        }
                        Console.WriteLine("WAIT...");
                        Thread.Sleep(1000);
                        Console.Clear();
                        break;
                    case 2:
                        Console.WriteLine("Enter subscriber name:");
                        string subName = Console.ReadLine();
                        Console.WriteLine("Enter sub ID:");
                        int Id = int.Parse(Console.ReadLine());
                        Subscriber newSub = new Subscriber(subName, Id);
                        library.AddSubscriber(newSub);
                        Console.WriteLine("WAIT...");
                        Thread.Sleep(1000);
                        Console.Clear();
                        break;
                    case 3:
                        Console.WriteLine("Enter subscriber ID:");
                        int loanSubId = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter book title:");
                        string loanBookTitle = Console.ReadLine();
                        Console.WriteLine("Enter book author:");
                        string loanBookAuthor = Console.ReadLine();
                        library.BorrowBook(loanSubId, loanBookTitle, loanBookAuthor);
                        Console.WriteLine("WAIT...");
                        Thread.Sleep(1000);
                        Console.Clear();
                        break;
                    case 4:
                        Console.WriteLine("Enter subscriber ID:");
                        int returnSubId = int.Parse(Console.ReadLine());
                        Console.WriteLine("Enter book title:");
                        string returnBookTitle = Console.ReadLine();
                        Console.WriteLine("Enter book author:");
                        string returnBookAuthor = Console.ReadLine();
                        library.BorrowBook(returnSubId, returnBookTitle, returnBookAuthor);
                        Console.WriteLine("WAIT...");
                        Thread.Sleep(1000);
                        Console.Clear();
                        break;
                    case 5:
                        library.AllBooksInfo();
                        Console.WriteLine("** " + new string('#', 25) + " **");
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                    case 6:
                        Console.WriteLine("Enter genre:");
                        string genre = Console.ReadLine();
                        library.DisplayBooksByGenre(genre);
                        Console.WriteLine("** " + new string('-', 25) + " **");
                        Thread.Sleep(5000);
                        Console.Clear();
                        break;
                    case 7:
                        isRunning = false;
                        Console.WriteLine("Goodbye.");
                        Console.WriteLine("-- " + new string('#', 25) + " --");
                        Thread.Sleep(1000);
                        Console.Clear();
                        return;
                }
            }
        }
    }

    class Book
    {
        public string Title { get; set; }
        public string AuthorName { get; set; }
        public bool IsLoaned { get; set; }

        public Book(string bookName, string authorName)
        {
            Title = bookName;
            AuthorName = authorName;
            IsLoaned = false;
        }

        public virtual void LoanBook()
        {
            if (IsLoaned)
            {
                Console.WriteLine("Book is already loaned.");
            }
            else
            {
                IsLoaned = true;
                Console.WriteLine("Book was successfully loaned.");
            }
        }

        public virtual void ReturnBook()
        {
            if (!IsLoaned)
            {
                Console.WriteLine("This book was not loaned.");
            }
            else
            {
                IsLoaned = false;
                Console.WriteLine("Book was returned successfully.");
            }
        }

        public override string ToString()
        {
            return $"{Title} from {AuthorName} {(IsLoaned ? "(is loaned)" : "(available)")}";
        }

        public override bool Equals(object obj)
        {
            if (obj is Book otherBook)
           {
                return Title == otherBook.Title && AuthorName == otherBook.AuthorName;
           }
            return false;
        }
    }
}

