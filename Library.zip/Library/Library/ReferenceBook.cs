﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    class ReferenceBook: Book
    {
        public bool IsAvailableForLoan { get; set; }
        public ReferenceBook(string bookName, string authorName, bool isAvailable) : base(bookName, authorName)
        {
            this.IsAvailableForLoan = isAvailable;
        }

        public override void LoanBook()
        {
            if (IsAvailableForLoan)
            {
                base.LoanBook();
            }
            else
            {
                Console.WriteLine($"Can be loaned: {IsAvailableForLoan}");
            }
        }

        public override string ToString()
        {
            return base.ToString() + (IsAvailableForLoan ? "Book can be loaned" : "Book cannot be loaned");
        }
    }
}
