﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    internal class Subscriber
    {
        public string SubName { get; set; }
        public int Id { get; set; }
        public int LoanedBooks { get; set;}

        public Subscriber(string subName, int id)
        {
            SubName = subName;
            Id = id;
            LoanedBooks = 0;
        }
        
        public void LoanBook()
        {
            LoanedBooks++;
        }
        public void ReturnBook()
        {
            if(LoanedBooks > 0)
            {
                LoanedBooks--;
            }
        }
        public void SubInfo()
        {
            Console.WriteLine($"Subscriber name: {SubName}, ID: {Id}, Loaned Books: {LoanedBooks}");
        }

        public override bool Equals(object obj)
        {
            if (obj is Subscriber otherSubscriber)
            {
                return Id == otherSubscriber.Id;
            }
            return false;
        }
    }
}
